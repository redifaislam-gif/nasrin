<div class="whb-html-block-element"><?php echo woodmart_get_html_block( $params['block_id'] ); ?></div>
